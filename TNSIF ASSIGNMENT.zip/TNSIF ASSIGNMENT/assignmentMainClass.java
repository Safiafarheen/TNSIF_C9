package Assignment;
	import com.safia.assignment.employees.Manager;
	import com.safia.assignment.employees.Developer;
	import com.safia.assignment.Utilities.EmployeeUtilities;

	public class assignmentMainClass {

	    public static void main(String[] args) {
	        Manager manager = new Manager("John Doe", 1001, 60000, "Marketing");
	        Developer developer = new Developer("Jane Smith", 2001, 75000, "Java");
	        EmployeeUtilities utilities = new EmployeeUtilities();
	        utilities.raiseSalary(manager, 10);
	        utilities.changeDepartment(manager, "Finance");
	        utilities.changeProgrammingLanguage(developer, "Python");
	        System.out.println("Manager's Updated Department: " + manager.getDepartment());
	        System.out.println("Developer's Updated Programming Language: " + developer.getProgrammingLanguage());
	        System.out.println("Manager's Updated Salary: " + manager.getSalary());
	    }
	}

