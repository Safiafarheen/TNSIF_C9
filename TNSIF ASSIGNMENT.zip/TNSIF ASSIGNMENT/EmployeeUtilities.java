package com.safia.assignment.Utilities;
import com.safia.assignment.employees.Employee;
import com.safia.assignment.employees.Manager;
import com.safia.assignment.employees.Developer;
public class EmployeeUtilities {
	public static void raiseSalary(Employee employee, double percentage) {
        double currentSalary = employee.getSalary();
        double raiseAmount = currentSalary * (percentage / 100);
        employee.setSalary(currentSalary + raiseAmount);
    }
    public void changeDepartment(Manager manager, String newDepartment) {
        manager.setDepartment(newDepartment);
    }
    public void changeProgrammingLanguage(Developer developer, String newLanguage) {
        developer.setProgrammingLanguage(newLanguage);
    }
}
