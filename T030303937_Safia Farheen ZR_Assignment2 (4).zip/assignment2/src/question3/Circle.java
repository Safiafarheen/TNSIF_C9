package question3;
import java.util.Scanner;

public class Circle {
    
    
    private double radius;
    private String color;
    
    
    public void getInput() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the radius of the circle:");
        radius = scanner.nextDouble();
        
        scanner.nextLine();
        
        System.out.println("Enter the color of the circle:");
        color = scanner.nextLine();
        
        scanner.close();
    }
    
    
    public void calcArea() {
        double area = Math.PI * radius * radius;
        System.out.println("Circle Details:");
        System.out.println("Radius: " + radius);
        System.out.println("Color: " + color);
        System.out.println("Area: " + area);
    }
    
    public static void main(String[] args) {
       
        Circle circle = new Circle();
        
        
        circle.getInput();
        
  
        circle.calcArea();
    }
}

