package question2;

public class Student {
	    public Student() {
	        System.out.println("Student object is created");
	    }

	    public static void main(String[] args) {
	        Student student = new Student();
	    }
	

}
