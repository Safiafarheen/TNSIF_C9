/**
 * 
 */
/**
 * 
 */
module miniProject {
	requires java.sql;
}